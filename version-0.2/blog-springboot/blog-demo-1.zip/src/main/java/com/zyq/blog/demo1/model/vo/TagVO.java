package com.zyq.blog.demo1.model.vo;

import lombok.Data;

@Data
public class TagVO {
    private String name;
    private String count;
}
